﻿using System.ComponentModel.DataAnnotations;

namespace GraduationProject.Models
{
    public class Teacher
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Specialization { get; set; }
        public int Salary { get; set; }
        public DateOnly HireDate { get; set; }
        public ICollection<HomeWork> HomeWorks { get; set; }
    }
}
