﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GraduationProject.DAL.Migrations
{
    /// <inheritdoc />
    public partial class third : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_StudentHomework_Students_StudentsSId",
                table: "StudentHomework");

            migrationBuilder.RenameColumn(
                name: "TName",
                table: "Teachers",
                newName: "Name");

            migrationBuilder.RenameColumn(
                name: "TId",
                table: "Teachers",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "SId",
                table: "Students",
                newName: "Id");

            migrationBuilder.RenameColumn(
                name: "StudentsSId",
                table: "StudentHomework",
                newName: "StudentsId");

            migrationBuilder.RenameIndex(
                name: "IX_StudentHomework_StudentsSId",
                table: "StudentHomework",
                newName: "IX_StudentHomework_StudentsId");

            migrationBuilder.AddForeignKey(
                name: "FK_StudentHomework_Students_StudentsId",
                table: "StudentHomework",
                column: "StudentsId",
                principalTable: "Students",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_StudentHomework_Students_StudentsId",
                table: "StudentHomework");

            migrationBuilder.RenameColumn(
                name: "Name",
                table: "Teachers",
                newName: "TName");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Teachers",
                newName: "TId");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Students",
                newName: "SId");

            migrationBuilder.RenameColumn(
                name: "StudentsId",
                table: "StudentHomework",
                newName: "StudentsSId");

            migrationBuilder.RenameIndex(
                name: "IX_StudentHomework_StudentsId",
                table: "StudentHomework",
                newName: "IX_StudentHomework_StudentsSId");

            migrationBuilder.AddForeignKey(
                name: "FK_StudentHomework_Students_StudentsSId",
                table: "StudentHomework",
                column: "StudentsSId",
                principalTable: "Students",
                principalColumn: "SId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
