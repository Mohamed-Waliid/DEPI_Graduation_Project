﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GraduationProject.DAL.Migrations
{
    /// <inheritdoc />
    public partial class fourth : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HomeWorks_Teachers_TId",
                table: "HomeWorks");

            migrationBuilder.RenameColumn(
                name: "TId",
                table: "HomeWorks",
                newName: "Id");

            migrationBuilder.RenameIndex(
                name: "IX_HomeWorks_TId",
                table: "HomeWorks",
                newName: "IX_HomeWorks_Id");

            migrationBuilder.AddForeignKey(
                name: "FK_HomeWorks_Teachers_Id",
                table: "HomeWorks",
                column: "Id",
                principalTable: "Teachers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HomeWorks_Teachers_Id",
                table: "HomeWorks");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "HomeWorks",
                newName: "TId");

            migrationBuilder.RenameIndex(
                name: "IX_HomeWorks_Id",
                table: "HomeWorks",
                newName: "IX_HomeWorks_TId");

            migrationBuilder.AddForeignKey(
                name: "FK_HomeWorks_Teachers_TId",
                table: "HomeWorks",
                column: "TId",
                principalTable: "Teachers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
