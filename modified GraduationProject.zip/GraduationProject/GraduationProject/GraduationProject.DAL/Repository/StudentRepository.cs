﻿using GraduationProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraduationProject.DAL.Repository
{
    public class StudentRepository : IStudentRepository
    {
        private readonly ProjectContext _projectContext;
        public StudentRepository(ProjectContext projectContext)
        {
            _projectContext = projectContext;
        }

        public void Add(Student student)
        {
            _projectContext.Students.Add(student);
            _projectContext.SaveChanges();
        }

        public void Delete(Student student)
        {
            _projectContext.Students.Remove(student);
            _projectContext.SaveChanges();
        }

        public IQueryable<Student> GetAll()
        {
            return _projectContext.Students;
        }

        public Student GetById(int id)
        {
            return _projectContext.Students.Find(id);
        }

        public void Update(Student student)
        {
            _projectContext.Students.Update(student);
            _projectContext.SaveChanges();
        }
    }
}
