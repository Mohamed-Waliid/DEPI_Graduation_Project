﻿using GraduationProject.Models;

namespace GraduationProject.BLL.DTOs
{
    public class HomeWorkAddDto
    {
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public Teacher Teacher { get; set; }  
        public List<int> StudentIds { get; set; }  
    }
}
