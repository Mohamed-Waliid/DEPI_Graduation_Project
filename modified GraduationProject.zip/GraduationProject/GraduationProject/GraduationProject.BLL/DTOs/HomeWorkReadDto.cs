﻿using System;
using System.Collections.Generic;

namespace GraduationProject.BLL.DTOs
{
    public class HomeWorkReadDto
    {
        public int HId { get; set; }
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public string? TeacherName { get; set; } // اسم المدرس المرتبط بالواجب
        public List<string>? StudentNames { get; set; } // أسماء الطلاب اللي مرتبطين بالواجب
    }
}
