﻿namespace GraduationProject.BLL.DTOs
{
    public class HomeWorkUpdateDto
    {
        public int HId { get; set; }
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public int TeacherId { get; set; }
        public List<int> StudentIds { get; set; }
    }
}
