﻿using GraduationProject.BLL.DTOs;
using GraduationProject.Models;

public interface IHomeWorkManager
{
    List<HomeWork> GetAll();
    HomeWork? GetById(int id);
    void Add(HomeWorkAddDto homeWorkAddDto);  
    void Update(HomeWorkUpdateDto homeWorkUpdateDto);
    void Delete(int id);
}
