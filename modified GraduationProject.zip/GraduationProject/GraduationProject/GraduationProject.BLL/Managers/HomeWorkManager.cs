﻿using GraduationProject.DAL;
using GraduationProject.Models;
using GraduationProject.BLL.DTOs;
using Microsoft.EntityFrameworkCore;

namespace GraduationProject.BLL.Managers
{
    public class HomeWorkManager : IHomeWorkManager
    {
        private readonly ProjectContext _context;

        public HomeWorkManager(ProjectContext context)
        {
            _context = context;
        }

        // Get all HomeWorks
        public List<HomeWork> GetAll()
        {
            return _context.HomeWorks
                .Include(h => h.Teacher) // لو حابب تجيب المدرس المرتبط
                .Include(h => h.Students) // لو حابب تجيب الطلاب المرتبطين
                .ToList();
        }

        // Get HomeWork by ID
        public HomeWork? GetById(int id)
        {
            return _context.HomeWorks
                .Include(h => h.Teacher) // لو حابب تجيب المدرس المرتبط
                .Include(h => h.Students) // لو حابب تجيب الطلاب المرتبطين
                .FirstOrDefault(h => h.HId == id);
        }

        // Add new HomeWork
        public void Add(HomeWorkAddDto homeWorkAddDto)
        {
            var homeWork = new HomeWork
            {
                Description = homeWorkAddDto.Description,
                DueDate = homeWorkAddDto.DueDate,
                Teacher = homeWorkAddDto.Teacher // ربط المدرس بالواجب
            };

            // إضافة الطلاب إلى الواجب بناءً على الـ IDs
            if (homeWorkAddDto.StudentIds != null && homeWorkAddDto.StudentIds.Any())
            {
                var students = _context.Students
                    .Where(s => homeWorkAddDto.StudentIds.Contains(s.Id))
                    .ToList();
                homeWork.Students = students;
            }

            _context.HomeWorks.Add(homeWork);
            _context.SaveChanges();
        }

        // Update an existing HomeWork
        public void Update(HomeWorkUpdateDto homeWorkUpdateDto)
        {
            var homeWork = _context.HomeWorks.Find(homeWorkUpdateDto.HId);
            if (homeWork != null)
            {
                homeWork.Description = homeWorkUpdateDto.Description;
                homeWork.DueDate = homeWorkUpdateDto.DueDate;

                _context.HomeWorks.Update(homeWork);
                _context.SaveChanges();
            }
        }

        // Delete HomeWork by ID
        public void Delete(int id)
        {
            var homeWork = _context.HomeWorks.Find(id);
            if (homeWork != null)
            {
                _context.HomeWorks.Remove(homeWork);
                _context.SaveChanges();
            }
        }
    }
}
