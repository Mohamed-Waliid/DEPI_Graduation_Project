﻿using GraduationProject.BLL.DTOs;
using GraduationProject.DAL;
using GraduationProject.DAL.Repository;
using GraduationProject.Models;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraduationProject.BLL.Managers
{
    public class StudentManager : IStudentManager
    {
        private readonly IStudentRepository studentRepository;
        private readonly IMemoryCache memoryCache;
        private const string KeyCache = "Cache_Student";
        public StudentManager(IStudentRepository _studentRepository, IMemoryCache _memoryCache)
        {
            studentRepository = _studentRepository;
            memoryCache = _memoryCache;
        }

        public void Add(StudentAddDto student)
        {
            var studentmodel = new Student()
            {
                Id = student.Id,
                Name = student.Name,
                Address = student.Address,
                Phone = student.Phone,
                ParentContact = student.ParentContact
            };
            studentRepository.Add(studentmodel);
        }

        public void Delete(int id)
        {
            var studentmodel = studentRepository.GetById(id);
            studentRepository.Delete(studentmodel);
            memoryCache.Remove(KeyCache);
        }

        public IEnumerable<StudentReadDto> GetAll()
        {
            if(!memoryCache.TryGetValue($"{KeyCache}", out IEnumerable<StudentReadDto> studentReadDto))
            {
                var studentmodel = studentRepository.GetAll();
                studentReadDto = studentmodel.Select(a => new StudentReadDto
                {
                    Id = a.Id,
                    Name = a.Name,
                    GradeLevel = a.GradeLevel
                }).ToList();

                MemoryCacheEntryOptions cache = new MemoryCacheEntryOptions()
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(3)
                };
                memoryCache.Set(KeyCache, studentReadDto, cache);
            }
            return studentReadDto;
        }

        public StudentReadDto GetById(int id)
        {
            var studentmodel = studentRepository.GetById(id);
            var studentReadDto = new StudentReadDto
            {
                Id = studentmodel.Id,
                Name = studentmodel.Name,
                GradeLevel = studentmodel.GradeLevel
            };
            return studentReadDto;
        }

        public void Update(StudentUpdateDto student)
        {
            var studentmodel = studentRepository.GetById(student.Id);
            studentmodel.Name = student.Name;
            studentmodel.Address = student.Address;
            studentmodel.Phone = student.Phone;
            studentmodel.ParentContact = student.ParentContact;
            studentmodel.GradeLevel = student.GradeLevel;
            studentRepository.Update(studentmodel);
            memoryCache.Remove(KeyCache);
        }
    }
}
