﻿using GraduationProject.BLL.DTOs;
using GraduationProject.BLL.Managers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GraduationProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeacherController : ControllerBase
    {
        private readonly ITeacherManager manager;
        public TeacherController(ITeacherManager _manager)
        {
            manager = _manager;
        }
        [HttpGet]
        public ActionResult GetAll()
        {
            return Ok(manager.GetAll());
        }
        [HttpGet("{id}")]
        public ActionResult GetById(int id)
        {
            return Ok(manager.GetById(id));
        }
        [HttpPost]
        public ActionResult Add(TeacherAddDto teacherAddDto)
        {
            manager.Add(teacherAddDto);
            return NoContent();
        }
        [HttpPut("{id}")]
        public ActionResult Update(int id ,  TeacherUpdateDto teacherUpdateDto)
        {
            if(id != teacherUpdateDto.Id)
            {
                return BadRequest();
            }
            manager.Update(teacherUpdateDto);
            return NoContent();
        }
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            manager.Delete(id);
            return NoContent();
        }
    }
}
