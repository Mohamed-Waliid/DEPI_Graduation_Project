﻿using GraduationProject.BLL.DTOs;
using GraduationProject.BLL.Managers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GraduationProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentManager studentManager;
        public StudentController(IStudentManager manager) 
        {
            studentManager = manager;
        }
        [HttpGet]
        public ActionResult GetAll()
        {
            return Ok(studentManager.GetAll());
        }
        [HttpGet("{id}")]
        public ActionResult GetById(int id)
        {
            return Ok(studentManager.GetById(id));
        }
        [HttpPut("{id}")]
        public ActionResult Update(int id, StudentUpdateDto studentUpdateDto)
        {
            if(id != studentUpdateDto.Id)
            {
                return BadRequest();
            }
            studentManager.Update(studentUpdateDto);
            return NoContent();
        }
        [HttpPost]
        public ActionResult Add(StudentAddDto studentAddDto)
        {
            studentManager.Add(studentAddDto);
            return NoContent();
        }
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            studentManager.Delete(id);
            return NoContent();
        }
    }
}
