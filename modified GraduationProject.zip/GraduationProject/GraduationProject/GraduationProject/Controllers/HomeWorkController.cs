﻿using GraduationProject.BLL.DTOs;
using GraduationProject.BLL.Managers;
using Microsoft.AspNetCore.Mvc;

namespace GraduationProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeWorkController : ControllerBase
    {
        private readonly IHomeWorkManager _manager;

        public HomeWorkController(IHomeWorkManager manager)
        {
            _manager = manager;
        }

        [HttpGet]
        public ActionResult GetAll()
        {
            return Ok(_manager.GetAll());
        }

        [HttpGet("{id}")]
        public ActionResult GetById(int id)
        {
            var homework = _manager.GetById(id);
            if (homework == null)
            {
                return NotFound();
            }
            return Ok(homework);
        }

        [HttpPost]
        public ActionResult Add(HomeWorkAddDto homeWorkAddDto)
        {
            _manager.Add(homeWorkAddDto);
            return NoContent();
        }

        [HttpPut("{id}")]
        public ActionResult Update(int id, HomeWorkUpdateDto homeWorkUpdateDto)
        {
            if (id != homeWorkUpdateDto.HId)
            {
                return BadRequest();
            }
            _manager.Update(homeWorkUpdateDto);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            _manager.Delete(id);
            return NoContent();
        }
    }
}
