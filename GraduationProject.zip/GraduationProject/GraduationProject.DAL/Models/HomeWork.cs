﻿using System.ComponentModel.DataAnnotations;

namespace GraduationProject.Models
{
    public class HomeWork
    {
        [Key] 
        public int HId { get; set; }
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public ICollection<Student> Students { get; set; }
        public Teacher Teacher { get; set; }
        public int Id { get; set; }
    }
}
