﻿using System.ComponentModel.DataAnnotations;

namespace GraduationProject.Models
{
    public class Student
    {
        
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string ParentContact { get; set; }
        public string? GradeLevel { get; set; }
        public DateOnly BirthDate { get; set; }
        public ICollection<HomeWork> HomeWorks { get; set; }
    }
}
