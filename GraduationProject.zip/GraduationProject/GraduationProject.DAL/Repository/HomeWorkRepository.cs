﻿using GraduationProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraduationProject.DAL.Repository
{
    public class HomeWorkRepository : IHomeWorkRepository
    {
        private readonly ProjectContext _projectContext;
        public HomeWorkRepository(ProjectContext projectContext)
        {
            _projectContext = projectContext;
        }

        public void Add(HomeWork homework)
        {
            _projectContext.HomeWorks.Add(homework);
            _projectContext.SaveChanges();
        }

        public void Delete(HomeWork homework)
        {
            _projectContext.HomeWorks.Remove(homework);
            _projectContext.SaveChanges();
        }

        public IQueryable<HomeWork> GetAll()
        {
            return _projectContext.HomeWorks;
        }

        public HomeWork GetById(int id)
        {
            return _projectContext.HomeWorks.Find(id);
        }

        public void Update(HomeWork homework)
        {
            _projectContext.HomeWorks.Update(homework);
            _projectContext.SaveChanges();
        }
    }
}
