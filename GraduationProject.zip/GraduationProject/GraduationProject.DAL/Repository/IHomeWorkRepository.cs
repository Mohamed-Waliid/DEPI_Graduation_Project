﻿using GraduationProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraduationProject.DAL.Repository
{
    public interface IHomeWorkRepository
    {
        IQueryable<HomeWork> GetAll();
        HomeWork GetById(int id);
        void Add(HomeWork homework);
        void Update(HomeWork homework);
        void Delete(HomeWork homework);
    }
}
