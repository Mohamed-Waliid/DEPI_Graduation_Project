﻿using GraduationProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraduationProject.DAL.Repository
{
    public interface ITeacherRepository
    {
        IQueryable<Teacher> GetAll();
        Teacher GetById(int id);
        void Add(Teacher teacher);
        void Update(Teacher teacher);
        void Delete(Teacher teacher);
    }
}
