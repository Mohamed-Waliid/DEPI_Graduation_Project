﻿using GraduationProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraduationProject.DAL.Repository
{
    public class TeacherRepository : ITeacherRepository
    {
        private readonly ProjectContext _projectContext;
        public TeacherRepository(ProjectContext projectContext)
        {
            _projectContext = projectContext;
        }

        public void Add(Teacher teacher)
        {
            _projectContext.Teachers.Add(teacher);
            _projectContext.SaveChanges();
        }

        public void Delete(Teacher teacher)
        {
            _projectContext.Teachers.Remove(teacher);
            _projectContext.SaveChanges();
        }

        public IQueryable<Teacher> GetAll()
        {
            return _projectContext.Teachers;
        }

        public Teacher GetById(int id)
        {
            return _projectContext.Teachers.Find(id);
        }

        public void Update(Teacher teacher)
        {
            _projectContext.Teachers.Update(teacher);
            _projectContext.SaveChanges();
        }
    }
}
