﻿using GraduationProject.Models;
using Microsoft.EntityFrameworkCore;

namespace GraduationProject.DAL
{
    public class ProjectContext : DbContext
    {
        public ProjectContext(DbContextOptions<ProjectContext> options) : base(options)
        {

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("SERVER = DESKTOP-PAULA; DATABASE = GraduationProject; INTEGRATED SECURITY = TRUE; TRUSTSERVERCERTIFICATE = TRUE;");
            base.OnConfiguring(optionsBuilder);
        }
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<HomeWork>()
                .HasMany(a => a.Students)
                .WithMany(a => a.HomeWorks)
                .UsingEntity(a => a.ToTable("StudentHomework"));

            modelBuilder.Entity<HomeWork>()
                .HasOne(a => a.Teacher)
                .WithMany(a => a.HomeWorks)
                .HasForeignKey(a => a.Id);

            modelBuilder.Entity<Teacher>()
                .Property(a => a.Name)
                .HasMaxLength(50)
                .IsRequired();


            modelBuilder.Entity<Teacher>()
                .Property(a => a.Salary)
                .HasDefaultValue(5000);


            modelBuilder.Entity<Student>()
                .Property(a => a.Name)
                .HasMaxLength(50)
                .IsRequired();

            base.OnModelCreating(modelBuilder);
        }
        public DbSet<Student> Students { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
        public DbSet<HomeWork> HomeWorks { get; set; }
    }
}
