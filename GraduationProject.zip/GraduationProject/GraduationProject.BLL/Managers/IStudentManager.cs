﻿using GraduationProject.BLL.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraduationProject.BLL.Managers
{
    public interface IStudentManager
    {
        IEnumerable<StudentReadDto> GetAll();
        StudentReadDto GetById(int id);
        void Add(StudentAddDto student);
        void Update (StudentUpdateDto student);
        void Delete(int id);
    }
}
