﻿using GraduationProject.BLL.DTOs;
using GraduationProject.DAL.Repository;
using GraduationProject.Models;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraduationProject.BLL.Managers
{
    public class TeacherManager : ITeacherManager
    {
        private readonly ITeacherRepository teacherRepository;
        private readonly IMemoryCache memoryCache;
        private const string KeyCache = "Teacher_Cache";
        public TeacherManager(ITeacherRepository _teacherRepository, IMemoryCache _memoryCache)
        {
            teacherRepository = _teacherRepository;
            memoryCache = _memoryCache;
        }
        public void Add(TeacherAddDto teacher)
        {
            var teachermodel = new Teacher
            {
                Id = teacher.Id,
                Name = teacher.Name,
                Specialization = teacher.Specialization,
                Phone = teacher.Phone,
                HireDate = teacher.HireDate,
            };
            teacherRepository.Add(teachermodel);
        }

        public void Delete(int id)
        {
            var teachermodel = teacherRepository.GetById(id);
            teacherRepository.Delete(teachermodel);
            memoryCache.Remove(KeyCache);
        }

        public IEnumerable<TeacherReadDto> GetAll()
        {
            if(!memoryCache.TryGetValue($"{KeyCache}", out IEnumerable<TeacherReadDto> teacherReadDto))
            {
                var teachermodel = teacherRepository.GetAll();
                teacherReadDto = teachermodel.Select(x => new TeacherReadDto
                {
                    Id = x.Id,
                    Name = x.Name,
                    Specialization = x.Specialization,
                    Phone = x.Phone
                }).ToList();

                MemoryCacheEntryOptions cacheOptions = new MemoryCacheEntryOptions()
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(3)
                };
                memoryCache.Set(KeyCache,teacherReadDto, cacheOptions);
            }
            return teacherReadDto;
        }

        public TeacherReadDto GetById(int id)
        {
            var teachermodel = teacherRepository.GetById(id);
            var teacherReadDto = new TeacherReadDto
            {
                Id = teachermodel.Id,
                Name = teachermodel.Name,
                Specialization = teachermodel.Specialization,
                Phone = teachermodel.Phone
            };
            return teacherReadDto;

        }

        public void Update(TeacherUpdateDto teacher)
        {
            var teachermodel = teacherRepository.GetById(teacher.Id);
            teachermodel.Name = teacher.Name;
            teachermodel.Salary = teacher.Salary;
            teachermodel.Phone = teacher.Phone;
            teacherRepository.Update(teachermodel);
            memoryCache.Remove(KeyCache);
        }
    }
}
