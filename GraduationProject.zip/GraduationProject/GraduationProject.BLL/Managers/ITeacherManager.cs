﻿using GraduationProject.BLL.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraduationProject.BLL.Managers
{
    public interface ITeacherManager
    {
        IEnumerable<TeacherReadDto> GetAll();
        TeacherReadDto GetById(int id);
        void Add(TeacherAddDto teacher);
        void Update(TeacherUpdateDto teacher);
        void Delete(int id);
    }
}
